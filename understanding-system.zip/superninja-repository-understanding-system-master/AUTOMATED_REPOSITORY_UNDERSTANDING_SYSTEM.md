# 自動化儲存庫理解系統

## 🎯 系統概述

本系統旨在解決儲存庫理解不足的問題，通過四個階段的系統性方法建立完整的知識庫和操作檢查機制，確保所有操作都在充分的上下文資訊下進行。

## 📋 系統架構

```
自動化儲存庫理解系統
├── 第一階段：儲存庫掃描和知識庫建立
├── 第二階段：操作前的檢查機制
├── 第三階段：視覺化與查詢系統
└── 第四階段：持續學習機制
```

## 🚀 執行流程

### 初始化環境

```bash
# 確保 Python 3.11+ 已安裝
python3 --version

# 安裝依賴（如果需要）
pip install pyyaml
```

### 完整執行流程

```bash
# 1. 執行第一階段：儲存庫掃描和知識庫建立
python3 phase1_scanner.py

# 2. 執行第二階段：操作前的檢查機制
python3 phase2_operation_checker.py

# 3. 執行第三階段：視覺化與查詢系統
python3 phase3_visualizer.py

# 4. 執行第四階段：持續學習機制
python3 phase4_learning_system.py
```

### 一鍵執行所有階段

```bash
# 創建執行腳本
cat > run_all_phases.sh << 'EOF'
#!/bin/bash
echo "🚀 開始執行自動化儲存庫理解系統..."

echo ""
echo "📊 第一階段：儲存庫掃描和知識庫建立"
python3 phase1_scanner.py

echo ""
echo "🛡️  第二階段：操作前的檢查機制"
python3 phase2_operation_checker.py

echo ""
echo "🔍 第三階段：視覺化與查詢系統"
python3 phase3_visualizer.py

echo ""
echo "🧠 第四階段：持續學習機制"
python3 phase4_learning_system.py

echo ""
echo "✅ 所有階段執行完成！"
echo "📁 查看生成的報告："
echo "   - phase1_report.md"
echo "   - phase2_report.md"
echo "   - phase3_report.md"
echo "   - phase4_report.md"
echo "   - PHASES_COMPLETION_SUMMARY.md"
EOF

chmod +x run_all_phases.sh
./run_all_phases.sh
```

## 📊 各階段詳細說明

### 第一階段：儲存庫掃描和知識庫建立

**目標**：建立完整的儲存庫知識庫

**執行命令**：
```bash
python3 phase1_scanner.py
```

**輸出檔案**：
- `knowledge_base.json` - 完整的儲存庫知識庫
- `phase1_report.md` - 第一階段報告

**功能特性**：
- 自動掃描所有目錄和檔案
- 分類目錄用途（configuration, governance, documentation等）
- 識別檔案類型（markdown, yaml, python, typescript等）
- 標記關鍵檔案（bootstrap, security, build, entry_points）
- 建立檔案關係圖

**統計指標**：
- 目錄總數
- 檔案總數
- 配置檔案數量
- 關鍵檔案數量

### 第二階段：操作前的檢查機制

**目標**：建立強制性操作檢查，防止盲目操作

**執行命令**：
```bash
python3 phase2_operation_checker.py
```

**輸出檔案**：
- `phase2_report.md` - 第二階段報告

**檢查項目**：
1. **上下文驗證** - 確認檔案/目錄存在於知識庫中
2. **影響評估** - 評估操作風險等級和影響範圍
3. **知識檢查** - 確保對檔案有完整的知識
4. **風險評估** - 識別關鍵檔案和高風險操作
5. **備份檢查** - 確認有適當的備份機制

**風險等級**：
- **Low** - 低風險操作，可以執行
- **Medium** - 中等風險，需要謹慎
- **High** - 高風險操作，可能需要額外審查

**禁止操作情況**：
- 刪除 bootstrap 關鍵檔案
- 刪除 security 關鍵檔案
- 在不檢查依賴的情況下修改關鍵檔案

### 第三階段：視覺化與查詢系統

**目標**：提供多維度的查詢和視覺化功能

**執行命令**：
```bash
python3 phase3_visualizer.py
```

**輸出檔案**：
- `phase3_report.md` - 第三階段報告

**查詢功能**：

1. **檔案上下文查詢**
```python
context = visualizer.query_file_context('path/to/file.py')
# 返回：檔案類型、目錄用途、依賴關係、風險等級等
```

2. **目錄結構查詢**
```python
structure = visualizer.query_directory_structure('path/to/directory')
# 返回：目錄用途、子目錄、檔案列表、統計資訊等
```

3. **模式搜尋**
```python
# 根據名稱搜尋
results = visualizer.search_by_pattern('config', search_type='name')

# 根據類型搜尋
results = visualizer.search_by_pattern('python', search_type='type')

# 根據用途搜尋
results = visualizer.search_by_pattern('configuration', search_type='purpose')
```

**統計功能**：
- 檔案類型分佈
- 目錄用途分佈
- 關鍵檔案統計

### 第四階段：持續學習機制

**目標**：建立從操作中學習的持續改進機制

**執行命令**：
```bash
python3 phase4_learning_system.py
```

**輸出檔案**：
- `phase4_report.md` - 第四階段報告
- `knowledge_base_backup_*.json` - 知識庫備份檔案

**學習功能**：

1. **操作回饋循環**
```python
learning_system.record_operation_feedback(
    operation={'operation': 'modify', 'target': 'config.yaml'},
    success=True,
    feedback="操作成功完成"
)
```

2. **失敗模式分析**
- 自動識別重複錯誤模式
- 生成預防措施
- 更新最佳實踐庫

3. **自動變化檢測**
- 掃描檔案系統變化
- 檢測新增/刪除的檔案和目錄
- 自動更新知識庫

4. **最佳實踐生成**
```python
learning_system.generate_best_practice(operation, error_feedback)
```

**系統健康監控**：
- 知識庫大小
- 學習活躍狀態
- 最佳實踐數量
- 總學習事件次數

## 📁 系統檔案結構

```
repository-understanding-system/
├── phase1_scanner.py                    # 第一階段掃描器
├── phase2_operation_checker.py          # 第二階段操作檢查器
├── phase3_visualizer.py                 # 第三階段視覺化查詢系統
├── phase4_learning_system.py            # 第四階段持續學習系統
├── auto_maintenance_wrapper.py          # 🤖 輕量級自動維護包裝器
├── automated_maintenance_system.py      # 進階自動維護系統
├── knowledge_base.json                   # 儲存庫知識庫
├── phase1_report.md                     # 第一階段報告
├── phase2_report.md                     # 第二階段報告
├── phase3_report.md                     # 第三階段報告
├── phase4_report.md                     # 第四階段報告
├── PHASES_COMPLETION_SUMMARY.md         # 完成總結
├── AUTOMATED_REPOSITORY_UNDERSTANDING_SYSTEM.md  # 本文檔
└── run_all_phases.sh                    # 一鍵執行腳本
```

## 🔧 使用方式

### 🤖 完全自動化模式（推薦）

**使用輕量級自動維護包裝器**：

```bash
# 啟動交互式選擇器
python3 auto_maintenance_wrapper.py

# 選項 1: 守護進程模式 - 持續監控和自動維護
# 選項 2: 工作流程集成 - 在工作前後執行維護
# 選項 3: 立即執行 - 單次執行維護
# 選項 4: 狀態檢查 - 檢查系統狀態
```

**自動維護特性**：
- ✅ **自動檢測** - 監控檔案系統變化
- ✅ **智能觸發** - 只在需要時執行維護
- ✅ **背景運行** - 不干擾主要工作
- ✅ **錯誤恢復** - 自動處理維護錯誤
- ✅ **狀態監控** - 實時顯示系統狀態

**集成到工作流程**：

```python
from auto_maintenance_wrapper import LightweightAutoMaintenance

# 在你的程式中集成
maintenance = LightweightAutoMaintenance()

# 工作開始前
if maintenance.check_if_maintenance_needed():
    maintenance.perform_maintenance()

# 執行你的主要工作
print("執行主要工作任務...")

# 工作結束後
if maintenance.check_if_maintenance_needed():
    maintenance.perform_maintenance()
```

### 基本使用

```bash
# 1. 初始化系統
python3 phase1_scanner.py

# 2. 檢查操作安全性
python3 phase2_operation_checker.py

# 3. 查詢檔案資訊
python3 phase3_visualizer.py

# 4. 運行學習系統
python3 phase4_learning_system.py
```

### 集成到開發流程

```bash
# 在 Git pre-commit hook 中使用
cat > .git/hooks/pre-commit << 'EOF'
#!/bin/bash
echo "🔍 檢查操作安全性..."
python3 phase2_operation_checker.py
if [ $? -ne 0 ]; then
    echo "❌ 操作檢查失敗，請檢查後再提交"
    exit 1
fi
echo "✅ 操作檢查通過"
EOF

chmod +x .git/hooks/pre-commit
```

### 定期更新知識庫

```bash
# 設置 cron job 定期執行
crontab -e

# 每天凌晨 2 點執行
0 2 * * * cd /path/to/repository && python3 phase4_learning_system.py
```

## 📊 監控和維護

### 查看系統狀態

```bash
# 查看知識庫大小
du -h knowledge_base.json

# 查看最新報告
cat PHASES_COMPLETION_SUMMARY.md

# 查看各階段報告
ls -la phase*_report.md
```

### 備份知識庫

```bash
# 手動備份
cp knowledge_base.json knowledge_base_backup_$(date +%Y%m%d_%H%M%S).json

# 自動備份（由第四階段系統處理）
```

### 清理舊備份

```bash
# 保留最近 7 天的備份
find . -name "knowledge_base_backup_*.json" -mtime +7 -delete
```

## 🎯 成功指標

### 量化指標

- **目錄掃描率**: 100%
- **檔案記錄率**: 100%
- **操作前檢查覆蓋率**: 95%+
- **盲目操作次數**: 0
- **關鍵檔案風險評估**: 100%
- **知識庫更新頻率**: 即時

### 質量指標

- 系統穩定性：所有階段都能正常執行
- 檢查準確性：正確識別高風險操作
- 查詢效率：快速響應查詢請求
- 學習效果：持續改進操作建議

## 🔍 故障排除

### 常見問題

1. **知識庫載入失敗**
   ```bash
   # 檢查檔案是否存在
   ls -la knowledge_base.json
   
   # 重新生成知識庫
   python3 phase1_scanner.py
   ```

2. **操作檢查超時**
   ```bash
   # 檢查系統資源
   top
   
   # 優化知識庫大小
   # 考慮過濾不必要的檔案
   ```

3. **查詢結果不正確**
   ```bash
   # 重新掃描儲存庫
   python3 phase1_scanner.py
   
   # 驗證知識庫完整性
   python3 -c "import json; kb=json.load(open('knowledge_base.json')); print(len(kb))"
   ```

## 🚀 未來改進方向

1. **增強 AI 推理**
   - 加入機器學習模型預測操作風險
   - 實現智能建議系統

2. **視覺化界面**
   - 開發 Web 界面顯示知識庫
   - 建立互動式關係圖

3. **自動化修復**
   - 對檢測到的問題提供自動修復建議
   - 實現一鍵修復功能

4. **協作功能**
   - 支持多人協作和知識共享
   - 建立團隊知識庫

5. **性能優化**
   - 優化大型儲存庫的掃描性能
   - 實現增量更新機制

## 📝 更新日誌

### v1.0.0 (2025-01-18)
- ✅ 完成所有四個階段的開發
- ✅ 建立完整的知識庫系統
- ✅ 實施操作檢查機制
- ✅ 開發視覺化查詢系統
- ✅ 建立持續學習機制
- ✅ 完成系統文檔和自動化腳本

## 👥 貢獻指南

1. Fork 本儲存庫
2. 創建功能分支 (`git checkout -b feature/AmazingFeature`)
3. 提交變更 (`git commit -m 'Add some AmazingFeature'`)
4. 推送到分支 (`git push origin feature/AmazingFeature`)
5. 開啟 Pull Request

## 📄 授權條款

本專案採用 MIT 授權條款

## 🙏 致謝

感謝所有為本專案做出貢獻的開發者

---

**系統版本**: v1.0.0  
**最後更新**: 2025-01-18  
**維護者**: SuperNinja Team  
**狀態**: ✅ 生產就緒