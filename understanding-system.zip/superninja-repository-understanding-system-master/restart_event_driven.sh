#!/bin/bash

# 重啟事件驅動系統

echo "🔄 重啟事件驅動系統..."

# 停止系統
./stop_event_driven.sh

# 等待一秒
sleep 1

# 啟動系統
./start_event_driven.sh

echo "✅ 系統已重啟"
