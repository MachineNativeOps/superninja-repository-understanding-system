#!/bin/bash

# 查看事件驅動系統日誌

if [ -f logs/event-driven.log ]; then
    echo "📝 事件驅動系統日誌 (最近50行):"
    echo "============================================================"
    tail -n 50 logs/event-driven.log
    echo "============================================================"
    echo ""
    echo "💡 持續監控: tail -f logs/event-driven.log"
else
    echo "⚠️  日誌檔案不存在"
fi
