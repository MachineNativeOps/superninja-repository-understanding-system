# 第三階段：視覺化與查詢系統報告

**生成日期**: 2026-01-16T13:00:28.924204
**階段**: Phase 3 - Visualization and Query System

## 📊 系統概覽

- **知識庫檔案數**: 7156
- **知識庫目錄數**: 2031
- **查詢次數**: 3

## 🔍 查詢功能

### 1. 檔案上下文查詢

```python
# 查詢檔案的完整上下文資訊
context = visualizer.query_file_context('path/to/file.py')
# 返回: 檔案類型、目錄用途、依賴關係、風險等級等
```

### 2. 目錄結構查詢

```python
# 查詢目錄的完整結構
structure = visualizer.query_directory_structure('path/to/directory')
# 返回: 目錄用途、子目錄、檔案列表、統計資訊等
```

### 3. 模式搜尋

```python
# 根據名稱搜尋
results = visualizer.search_by_pattern('config', search_type='name')

# 根據類型搜尋
results = visualizer.search_by_pattern('python', search_type='type')

# 根據用途搜尋
results = visualizer.search_by_pattern('configuration', search_type='purpose')
```

## 📈 統計資訊

### 檔案類型分佈

| 類型 | 數量 | 百分比 |
|------|------|--------|
| markdown | 1699 | 23.7% |
| yaml | 1514 | 21.2% |
| python | 1348 | 18.8% |
| typescript | 630 | 8.8% |
| text | 522 | 7.3% |
| react | 447 | 6.2% |
| json | 434 | 6.1% |
| unknown | 351 | 4.9% |
| shell | 145 | 2.0% |
| javascript | 38 | 0.5% |

### 目錄用途分佈

| 用途 | 數量 | 百分比 |
|------|------|--------|
| configuration | 438 | 21.6% |
| governance | 306 | 15.1% |
| documentation | 300 | 14.8% |
| python_code | 290 | 14.3% |
| unknown | 248 | 12.2% |
| javascript_code | 184 | 9.1% |
| testing | 124 | 6.1% |
| source_code | 49 | 2.4% |
| scripts | 35 | 1.7% |
| tools | 16 | 0.8% |

## 🔗 檔案關係圖示例

系統能夠識別和分析檔案之間的關係：

- **依賴關係**: 哪些檔案依賴於當前檔案
- **影響範圍**: 修改當前檔案會影響哪些其他檔案
- **風險評估**: 基於檔案類型和用途的風險等級
- **關鍵性**: 標記系統關鍵檔案

